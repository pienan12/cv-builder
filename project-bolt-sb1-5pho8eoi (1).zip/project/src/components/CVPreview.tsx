import React from 'react';
import { Mail, Phone, MapPin, User, Calendar, Globe } from 'lucide-react';
import { CVData } from '../types/cv';

interface CVPreviewProps {
  data: CVData;
}

export function CVPreview({ data }: CVPreviewProps) {
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', { year: 'numeric', month: 'long' });
  };

  return (
    <div id="cv-preview" className="bg-white shadow-2xl rounded-lg overflow-hidden max-w-4xl mx-auto">
      <div className="grid grid-cols-3 min-h-[1000px]">
        {/* Sidebar gauche */}
        <div className="bg-gradient-to-b from-slate-800 to-slate-900 text-white p-8">
          {/* Photo */}
          <div className="text-center mb-8">
            {data.personalInfo.photo ? (
              <img
                src={data.personalInfo.photo}
                alt="Profile"
                className="w-32 h-32 rounded-full object-cover mx-auto border-4 border-white shadow-lg"
              />
            ) : (
              <div className="w-32 h-32 rounded-full bg-slate-600 border-4 border-white flex items-center justify-center mx-auto">
                <User className="w-16 h-16 text-slate-300" />
              </div>
            )}
          </div>

          {/* Contact */}
          <div className="mb-8">
            <h3 className="text-lg font-bold mb-4 text-blue-300 border-b border-slate-600 pb-2">
              CONTACT
            </h3>
            <div className="space-y-3 text-sm">
              {data.personalInfo.email && (
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-blue-300 flex-shrink-0" />
                  <span className="break-all">{data.personalInfo.email}</span>
                </div>
              )}
              {data.personalInfo.phone && (
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-blue-300 flex-shrink-0" />
                  <span>{data.personalInfo.phone}</span>
                </div>
              )}
              {(data.personalInfo.address || data.personalInfo.city) && (
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-blue-300 flex-shrink-0 mt-0.5" />
                  <div>
                    {data.personalInfo.address && <div>{data.personalInfo.address}</div>}
                    {data.personalInfo.city && <div>{data.personalInfo.city}</div>}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Compétences */}
          {data.skills.length > 0 && (
            <div className="mb-8">
              <h3 className="text-lg font-bold mb-4 text-blue-300 border-b border-slate-600 pb-2">
                COMPÉTENCES
              </h3>
              <div className="space-y-2">
                {data.skills.map((skill, index) => (
                  <div key={index} className="text-sm">
                    <div className="flex justify-between items-center mb-1">
                      <span>{skill}</span>
                    </div>
                    <div className="w-full bg-slate-600 rounded-full h-2">
                      <div className="bg-blue-400 h-2 rounded-full w-4/5"></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Centres d'intérêt */}
          {data.hobbies.length > 0 && (
            <div>
              <h3 className="text-lg font-bold mb-4 text-blue-300 border-b border-slate-600 pb-2">
                CENTRES D'INTÉRÊT
              </h3>
              <div className="space-y-2">
                {data.hobbies.map((hobby, index) => (
                  <div key={index} className="text-sm flex items-center gap-2">
                    <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    <span>{hobby}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Contenu principal */}
        <div className="col-span-2 p-8">
          {/* En-tête */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-slate-800 mb-2">
              {data.personalInfo.firstName} {data.personalInfo.lastName}
            </h1>
            {data.personalInfo.title && (
              <h2 className="text-xl text-blue-600 font-medium mb-4">
                {data.personalInfo.title}
              </h2>
            )}
            {data.personalInfo.summary && (
              <div className="bg-slate-50 p-4 rounded-lg border-l-4 border-blue-600">
                <p className="text-slate-700 leading-relaxed text-sm">
                  {data.personalInfo.summary}
                </p>
              </div>
            )}
          </div>

          {/* Expérience professionnelle */}
          {data.experiences.length > 0 && (
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <div className="w-4 h-4 bg-white rounded-full"></div>
                </div>
                EXPÉRIENCE PROFESSIONNELLE
              </h3>
              <div className="space-y-6">
                {data.experiences.map((exp, index) => (
                  <div key={exp.id} className="relative">
                    {index !== data.experiences.length - 1 && (
                      <div className="absolute left-4 top-8 w-0.5 h-full bg-slate-200"></div>
                    )}
                    <div className="flex gap-4">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                      </div>
                      <div className="flex-1">
                        <div className="mb-2">
                          <h4 className="text-lg font-semibold text-slate-800">{exp.position}</h4>
                          <p className="text-blue-600 font-medium">{exp.company}</p>
                          <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {formatDate(exp.startDate)} - {exp.current ? 'Présent' : formatDate(exp.endDate)}
                            </span>
                          </div>
                        </div>
                        {exp.description && (
                          <p className="text-slate-700 text-sm leading-relaxed">
                            {exp.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Formation */}
          {data.education.length > 0 && (
            <div>
              <h3 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-3">
                <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                  <div className="w-4 h-4 bg-white rounded-full"></div>
                </div>
                FORMATION
              </h3>
              <div className="space-y-6">
                {data.education.map((edu, index) => (
                  <div key={edu.id} className="relative">
                    {index !== data.education.length - 1 && (
                      <div className="absolute left-4 top-8 w-0.5 h-full bg-slate-200"></div>
                    )}
                    <div className="flex gap-4">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                      </div>
                      <div className="flex-1">
                        <div className="mb-2">
                          <h4 className="text-lg font-semibold text-slate-800">{edu.degree}</h4>
                          <p className="text-green-600 font-medium">{edu.institution}</p>
                          {edu.field && <p className="text-slate-600 text-sm">{edu.field}</p>}
                          <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {formatDate(edu.startDate)} - {edu.current ? 'En cours' : formatDate(edu.endDate)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}