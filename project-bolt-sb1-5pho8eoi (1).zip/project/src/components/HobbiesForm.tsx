import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';

interface HobbiesFormProps {
  hobbies: string[];
  onChange: (hobbies: string[]) => void;
}

export function HobbiesForm({ hobbies, onChange }: HobbiesFormProps) {
  const [newHobby, setNewHobby] = useState('');

  const addHobby = () => {
    if (newHobby.trim() && !hobbies.includes(newHobby.trim())) {
      onChange([...hobbies, newHobby.trim()]);
      setNewHobby('');
    }
  };

  const removeHobby = (hobby: string) => {
    onChange(hobbies.filter(h => h !== hobby));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      addHobby();
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={newHobby}
          onChange={(e) => setNewHobby(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ajouter un centre d'intérêt..."
          className="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
        />
        <button
          onClick={addHobby}
          className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Ajouter
        </button>
      </div>
      
      <div className="flex flex-wrap gap-2">
        {hobbies.map((hobby, index) => (
          <span
            key={index}
            className="inline-flex items-center gap-1 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm"
          >
            {hobby}
            <button
              onClick={() => removeHobby(hobby)}
              className="text-purple-600 hover:text-purple-800"
            >
              <X className="w-3 h-3" />
            </button>
          </span>
        ))}
      </div>
    </div>
  );
}