import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Experience } from '../types/cv';
import { InputField } from './InputField';
import { TextAreaField } from './TextAreaField';

interface ExperienceFormProps {
  experiences: Experience[];
  onChange: (experiences: Experience[]) => void;
}

export function ExperienceForm({ experiences, onChange }: ExperienceFormProps) {
  const addExperience = () => {
    const newExperience: Experience = {
      id: Date.now().toString(),
      company: '',
      position: '',
      startDate: '',
      endDate: '',
      current: false,
      description: ''
    };
    onChange([...experiences, newExperience]);
  };

  const removeExperience = (id: string) => {
    onChange(experiences.filter(exp => exp.id !== id));
  };

  const updateExperience = (id: string, field: keyof Experience, value: any) => {
    onChange(experiences.map(exp => 
      exp.id === id ? { ...exp, [field]: value } : exp
    ));
  };

  return (
    <div>
      {experiences.map((experience, index) => (
        <div key={experience.id} className="border-l-4 border-blue-500 pl-4 mb-6 pb-4 border-b border-gray-200 last:border-b-0">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium text-gray-900">Expérience {index + 1}</h3>
            {experiences.length > 1 && (
              <button
                onClick={() => removeExperience(experience.id)}
                className="text-red-500 hover:text-red-700 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField
              label="Entreprise"
              value={experience.company}
              onChange={(value) => updateExperience(experience.id, 'company', value)}
              required
            />
            <InputField
              label="Poste"
              value={experience.position}
              onChange={(value) => updateExperience(experience.id, 'position', value)}
              required
            />
            <InputField
              label="Date de début"
              value={experience.startDate}
              onChange={(value) => updateExperience(experience.id, 'startDate', value)}
              type="month"
            />
            <InputField
              label="Date de fin"
              value={experience.endDate}
              onChange={(value) => updateExperience(experience.id, 'endDate', value)}
              type="month"
            />
          </div>
          
          <div className="mb-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={experience.current}
                onChange={(e) => updateExperience(experience.id, 'current', e.target.checked)}
                className="mr-2"
              />
              <span className="text-sm text-gray-700">Poste actuel</span>
            </label>
          </div>
          
          <TextAreaField
            label="Description"
            value={experience.description}
            onChange={(value) => updateExperience(experience.id, 'description', value)}
            placeholder="Décrivez vos responsabilités et réalisations..."
            rows={4}
          />
        </div>
      ))}
      
      <button
        onClick={addExperience}
        className="flex items-center gap-2 text-blue-600 hover:text-blue-800 transition-colors"
      >
        <Plus className="w-4 h-4" />
        Ajouter une expérience
      </button>
    </div>
  );
}