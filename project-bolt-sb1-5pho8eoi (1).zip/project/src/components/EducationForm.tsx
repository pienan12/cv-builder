import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Education } from '../types/cv';
import { InputField } from './InputField';

interface EducationFormProps {
  education: Education[];
  onChange: (education: Education[]) => void;
}

export function EducationForm({ education, onChange }: EducationFormProps) {
  const addEducation = () => {
    const newEducation: Education = {
      id: Date.now().toString(),
      institution: '',
      degree: '',
      field: '',
      startDate: '',
      endDate: '',
      current: false
    };
    onChange([...education, newEducation]);
  };

  const removeEducation = (id: string) => {
    onChange(education.filter(edu => edu.id !== id));
  };

  const updateEducation = (id: string, field: keyof Education, value: any) => {
    onChange(education.map(edu => 
      edu.id === id ? { ...edu, [field]: value } : edu
    ));
  };

  return (
    <div>
      {education.map((edu, index) => (
        <div key={edu.id} className="border-l-4 border-green-500 pl-4 mb-6 pb-4 border-b border-gray-200 last:border-b-0">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium text-gray-900">Formation {index + 1}</h3>
            {education.length > 1 && (
              <button
                onClick={() => removeEducation(edu.id)}
                className="text-red-500 hover:text-red-700 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField
              label="Institution"
              value={edu.institution}
              onChange={(value) => updateEducation(edu.id, 'institution', value)}
              required
            />
            <InputField
              label="Diplôme"
              value={edu.degree}
              onChange={(value) => updateEducation(edu.id, 'degree', value)}
              required
            />
            <InputField
              label="Domaine d'études"
              value={edu.field}
              onChange={(value) => updateEducation(edu.id, 'field', value)}
            />
            <div></div>
            <InputField
              label="Date de début"
              value={edu.startDate}
              onChange={(value) => updateEducation(edu.id, 'startDate', value)}
              type="month"
            />
            <InputField
              label="Date de fin"
              value={edu.endDate}
              onChange={(value) => updateEducation(edu.id, 'endDate', value)}
              type="month"
            />
          </div>
          
          <div className="mt-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={edu.current}
                onChange={(e) => updateEducation(edu.id, 'current', e.target.checked)}
                className="mr-2"
              />
              <span className="text-sm text-gray-700">En cours</span>
            </label>
          </div>
        </div>
      ))}
      
      <button
        onClick={addEducation}
        className="flex items-center gap-2 text-green-600 hover:text-green-800 transition-colors"
      >
        <Plus className="w-4 h-4" />
        Ajouter une formation
      </button>
    </div>
  );
}