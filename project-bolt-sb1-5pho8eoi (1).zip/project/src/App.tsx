import React from 'react';
import { 
  User, 
  Briefcase, 
  GraduationCap, 
  Award, 
  Heart, 
  Download,
  FileText
} from 'lucide-react';
import { CVData } from './types/cv';
import { FormSection } from './components/FormSection';
import { InputField } from './components/InputField';
import { TextAreaField } from './components/TextAreaField';
import { PhotoUpload } from './components/PhotoUpload';
import { ExperienceForm } from './components/ExperienceForm';
import { EducationForm } from './components/EducationForm';
import { SkillsForm } from './components/SkillsForm';
import { HobbiesForm } from './components/HobbiesForm';
import { CVPreview } from './components/CVPreview';
import { useLocalStorage } from './hooks/useLocalStorage';
import { generatePDF } from './utils/pdfGenerator';

const initialCVData: CVData = {
  personalInfo: {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    photo: '',
    title: '',
    summary: ''
  },
  experiences: [{
    id: '1',
    company: '',
    position: '',
    startDate: '',
    endDate: '',
    current: false,
    description: ''
  }],
  education: [{
    id: '1',
    institution: '',
    degree: '',
    field: '',
    startDate: '',
    endDate: '',
    current: false
  }],
  skills: [],
  hobbies: []
};

function App() {
  const [cvData, setCvData] = useLocalStorage<CVData>('cv-data', initialCVData);

  const updatePersonalInfo = (field: string, value: string) => {
    setCvData(prev => ({
      ...prev,
      personalInfo: {
        ...prev.personalInfo,
        [field]: value
      }
    }));
  };

  const handleDownloadPDF = async () => {
    const fileName = `CV_${cvData.personalInfo.firstName}_${cvData.personalInfo.lastName}.pdf`;
    await generatePDF('cv-preview', fileName);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">CV Builder</h1>
            </div>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
            >
              <Download className="w-4 h-4" />
              Télécharger PDF
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Form Panel */}
          <div className="space-y-6">
            {/* Personal Information */}
            <FormSection title="Informations Personnelles" icon={<User className="w-5 h-5" />}>
              <PhotoUpload
                photo={cvData.personalInfo.photo}
                onChange={(photo) => updatePersonalInfo('photo', photo)}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField
                  label="Prénom"
                  value={cvData.personalInfo.firstName}
                  onChange={(value) => updatePersonalInfo('firstName', value)}
                  required
                />
                <InputField
                  label="Nom"
                  value={cvData.personalInfo.lastName}
                  onChange={(value) => updatePersonalInfo('lastName', value)}
                  required
                />
              </div>
              
              <InputField
                label="Titre professionnel"
                value={cvData.personalInfo.title}
                onChange={(value) => updatePersonalInfo('title', value)}
                placeholder="ex: Développeur Full-Stack"
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField
                  label="Email"
                  value={cvData.personalInfo.email}
                  onChange={(value) => updatePersonalInfo('email', value)}
                  type="email"
                />
                <InputField
                  label="Téléphone"
                  value={cvData.personalInfo.phone}
                  onChange={(value) => updatePersonalInfo('phone', value)}
                  type="tel"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField
                  label="Adresse"
                  value={cvData.personalInfo.address}
                  onChange={(value) => updatePersonalInfo('address', value)}
                />
                <InputField
                  label="Ville"
                  value={cvData.personalInfo.city}
                  onChange={(value) => updatePersonalInfo('city', value)}
                />
              </div>
              
              <TextAreaField
                label="Résumé professionnel"
                value={cvData.personalInfo.summary}
                onChange={(value) => updatePersonalInfo('summary', value)}
                placeholder="Décrivez brièvement votre profil professionnel..."
                rows={4}
              />
            </FormSection>

            {/* Experience */}
            <FormSection title="Expérience Professionnelle" icon={<Briefcase className="w-5 h-5" />}>
              <ExperienceForm
                experiences={cvData.experiences}
                onChange={(experiences) => setCvData(prev => ({ ...prev, experiences }))}
              />
            </FormSection>

            {/* Education */}
            <FormSection title="Formation" icon={<GraduationCap className="w-5 h-5" />}>
              <EducationForm
                education={cvData.education}
                onChange={(education) => setCvData(prev => ({ ...prev, education }))}
              />
            </FormSection>

            {/* Skills */}
            <FormSection title="Compétences" icon={<Award className="w-5 h-5" />}>
              <SkillsForm
                skills={cvData.skills}
                onChange={(skills) => setCvData(prev => ({ ...prev, skills }))}
              />
            </FormSection>

            {/* Hobbies */}
            <FormSection title="Centres d'Intérêt" icon={<Heart className="w-5 h-5" />}>
              <HobbiesForm
                hobbies={cvData.hobbies}
                onChange={(hobbies) => setCvData(prev => ({ ...prev, hobbies }))}
              />
            </FormSection>
          </div>

          {/* Preview Panel */}
          <div className="lg:sticky lg:top-8 lg:self-start">
            <div className="bg-gray-100 p-4 rounded-lg">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 text-center">
                Aperçu du CV
              </h2>
              <div className="transform scale-75 origin-top">
                <CVPreview data={cvData} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;